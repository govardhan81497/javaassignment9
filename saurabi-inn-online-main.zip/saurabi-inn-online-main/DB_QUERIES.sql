CREATE DATABASE IF NOT EXISTS SAURABHI_ONLINE;

SHOW DATABASES;

Use SAURABHI_ONLINE;

DROP TABLE IF EXISTS users;

CREATE TABLE users (
  user_id bigint unsigned NOT NULL AUTO_INCREMENT,
  firstname varchar(100) NOT NULL,
  lastname varchar(100) NOT NULL,
  email varchar(250) NOT NULL,
  password varchar(100) NOT NULL,
  enabled boolean  NOT NULL,
  PRIMARY KEY (user_id),
  UNIQUE KEY `email_unique` (`email`)
);

SHOW TABLES;

DESCRIBE SAURABHI_ONLINE.users;

select COLUMN_NAME, CONSTRAINT_NAME, REFERENCED_COLUMN_NAME, REFERENCED_TABLE_NAME,TABLE_SCHEMA
from information_schema.KEY_COLUMN_USAGE
where TABLE_NAME = 'users' and TABLE_SCHEMA='saurabhi_online';

SHOW INDEX FROM SAURABHI_ONLINE.users;

DROP TABLE IF EXISTS authorities;

  create table authorities (
	 id bigint unsigned NOT NULL AUTO_INCREMENT,
     email varchar(100) NOT NULL,
     authority varchar(50) NOT NULL,
     constraint fk_authorities_users foreign key(email) references users(email),
     PRIMARY KEY (`id`),
     UNIQUE KEY `email_authorities_unique` (`email`, `authority`)
);

DESCRIBE SAURABHI_ONLINE.authorities;

select COLUMN_NAME, CONSTRAINT_NAME, REFERENCED_COLUMN_NAME, REFERENCED_TABLE_NAME
from information_schema.KEY_COLUMN_USAGE
where TABLE_NAME = 'authorities' and TABLE_SCHEMA='saurabhi_online';
     
SHOW INDEX FROM SAURABHI_ONLINE.authorities;     

select * from users;
select * from authorities order by id;

INSERT INTO `users` (`firstname`,`lastname`,`email`,`password`,`enabled`)
VALUES ('supriyo','mukherjee','sup.muk@gmail.com',
'$2a$10$XptfskLsT1l/bRTLRiiCgejHqOpgXFreUnNUa35gJdCr2v2QbVFzu',
true);

INSERT INTO authorities (email, authority)
  values ('sup.muk@gmail.com', 'ROLE_USER');
 
INSERT INTO `users` (`firstname`,`lastname`,`email`,`password`,`enabled`)
VALUES ('admin','mukherjee','adm.muk@gmail.com',
'$2a$10$zxvEq8XzYEYtNjbkRsJEbukHeRx3XS6MDXHMu8cNuNsRfZJWwswDy', true);

INSERT INTO authorities (email, authority)
  values ('adm.muk@gmail.com', 'ROLE_ADMIN');

DROP TABLE IF EXISTS items;
CREATE TABLE items (
  id bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `price` DECIMAL(8, 2) NOT NULL,
  active boolean  NOT NULL,
  PRIMARY KEY (id) 
);

INSERT INTO `items` (`name`,`price`,`active`) VALUES ('Hydrabadi Chicken Biryani',280.00,true);
INSERT INTO `items` (`name`,`price`,`active`) VALUES ('Tandoori Paneer Tikka',220.00,true);
INSERT INTO `items` (`name`,`price`,`active`) VALUES ('Shahi Paneer',210.00,true);
INSERT INTO `items` (`name`,`price`,`active`) VALUES ('Veg Hakka Noodles',140.00,true);
INSERT INTO `items` (`name`,`price`,`active`) VALUES ('Matka Biryani With Raita',220.00,true);
INSERT INTO `items` (`name`,`price`,`active`) VALUES ('Tandoori Chicken',360.00,true);
INSERT INTO `items` (`name`,`price`,`active`) VALUES ('Gobi Manchurian',140.00,true);
INSERT INTO `items` (`name`,`price`,`active`) VALUES ('Fish Green Masala',220.00,true);

select * from items;

DROP TABLE IF EXISTS `orders`;

  CREATE TABLE `saurabhi_online`.`orders` (
  `id` BIGINT unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `grand_total` FLOAT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_order_user` (`user_id` ASC),
  CONSTRAINT `fk_order_user`
    FOREIGN KEY (`user_id`)
    REFERENCES `saurabhi_online`.`users` (`user_id`)
   );
   
   select * from orders;
   
select max(id) from orders where user_id=6;

select * from orders where DATE(created_at)=DATE(SYSDATE());

select month(created_at),sum(grand_total)
     from orders
     where MONTH(SYSDATE())=MONTH(created_at);


   
DROP TABLE IF EXISTS `order_item`; 
   
CREATE TABLE `saurabhi_online`.`order_item` (
  `id` BIGINT unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `price` FLOAT NOT NULL DEFAULT 0,
  `quantity` smallint NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  INDEX `idx_order_item_order` (`order_id` ASC),
  CONSTRAINT `fk_order_item_order`
    FOREIGN KEY (`order_id`)
    REFERENCES `saurabhi_online`.`orders` (`id`)
   );

ALTER TABLE `saurabhi_online`.`order_item` 
ADD INDEX `idx_order_item_item` (`item_id` ASC);
ALTER TABLE `saurabhi_online`.`order_item` 
ADD CONSTRAINT `fk_order_item_item`
  FOREIGN KEY (`item_id`)
  REFERENCES `saurabhi_online`.`items` (`id`);
  
   select * from order_item;
   
DROP TABLE IF EXISTS `audit_log`; 

CREATE TABLE `saurabhi_online`.`audit_log` (
  `id` BIGINT unsigned NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(2000) NOT NULL,
   PRIMARY KEY (`id`)
   );
   
    select * from audit_log;  