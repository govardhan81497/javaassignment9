package com.saurabi.online.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import springfox.documentation.annotations.ApiIgnore;

@ApiIgnore
@Controller
@RequestMapping("/")
public class AppErrorController implements ErrorController {
	private static final String ERROR_PATH = "/error";

	@GetMapping(value=ERROR_PATH)
	public ResponseEntity<String> genericErrorHandler() {
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("You are unauthorrised to access the URL");
	}	
}
