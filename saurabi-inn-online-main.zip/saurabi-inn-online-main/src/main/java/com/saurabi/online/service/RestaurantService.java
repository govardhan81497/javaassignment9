package com.saurabi.online.service;

import java.util.List;

import com.saurabi.online.entity.Item;
import com.saurabi.online.entity.Order;
import com.saurabi.online.exception.UserException;
import com.saurabi.online.model.dto.CreateOrderDTO;
import com.saurabi.online.model.dto.ItemDTO;
import com.saurabi.online.model.dto.OrderDTO;

public interface RestaurantService {

	Item getItemById(long id);

	List<ItemDTO> getAllItems();

	Order createSingleOrder(CreateOrderDTO orderDetails) throws UserException;

	OrderDTO getFinalBillOfUser() throws UserException;

	List<OrderDTO> getAllBillsGeneratedToday() throws UserException;

	double getTotalSalesOfCurrentMonth();

}