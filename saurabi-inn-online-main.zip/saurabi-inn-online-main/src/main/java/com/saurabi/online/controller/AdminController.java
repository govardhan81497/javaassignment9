package com.saurabi.online.controller;

import java.time.LocalDate;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.saurabi.online.entity.User;
import com.saurabi.online.exception.UserException;
import com.saurabi.online.model.dto.OrderDTO;
import com.saurabi.online.model.dto.UserDTO;
import com.saurabi.online.service.RestaurantService;
import com.saurabi.online.utility.AppUtility;

@RestController
public class AdminController {

	@Autowired
	com.saurabi.online.service.UserService UserService;
	
	@Autowired
	RestaurantService  restaurantService;

	@GetMapping("adminControl/showUser")
	public ResponseEntity<UserDTO> showUserByEmail(String email) {
		
		final UserDTO existingUser = AppUtility.getUserDTOFromUser(UserService.loadUserByEmail(email));	
		
		if(existingUser != null) {
			existingUser.setPassword("***********");
			return new ResponseEntity<UserDTO>(existingUser, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<UserDTO>(existingUser, HttpStatus.CONFLICT);
		}
	}

	@GetMapping("adminControl/user/{email}")
	public String checkIfUserExists(@PathVariable("email") String email) {
		boolean flag = checkIfUserExistsByEmail(email);
		if (flag)
			return "\"" + email + "\" exist in Database";
		else
			return "\"" + email + "\" does not exist in Database";
	}

	public boolean checkIfUserExistsByEmail(String email) {
		return UserService.userExists(email);

	}

	@PostMapping("adminControl/createUser")
	public ResponseEntity<String> createUser(@Valid @RequestBody UserDTO userDetails) {

		if (!checkIfUserExistsByEmail(userDetails.getEmail())) {
			final User createdUser = UserService.createSingleUser(userDetails);
			if(createdUser != null) {
				return new ResponseEntity<String>("User Created Successfully", HttpStatus.CREATED);
			}else {
				return new ResponseEntity<String>("User Creation Failed!!", HttpStatus.CONFLICT);
			}
		} else {
			throw new UserException(
					userDetails.getEmail().concat(" already exists. Please try with a different user"));
		}
	}

	@PutMapping("adminControl/updateUser")
	public ResponseEntity<String> updateUser(@Valid @RequestBody UserDTO userDetails) {
		if (checkIfUserExistsByEmail(userDetails.getEmail())) {
			final User updatedUser = UserService.updateSingleUser(userDetails);
			if(updatedUser != null) {
				return new ResponseEntity<String>("User updated Successfully", HttpStatus.CREATED);
			}else {
				return new ResponseEntity<String>("User update Failed!!", HttpStatus.CONFLICT);
			}
		} else {
			throw new UserException(
					userDetails.getEmail().concat(" does not exists. Please try with a different user"));
		}
	}

	@DeleteMapping("adminControl/deleteUser/{byEmail}")
	public ResponseEntity<String> deleteUser(@PathVariable("byEmail") String email) {
		UserService.deleteSingleUser(email);
		if(checkIfUserExistsByEmail(email)) {
			return new ResponseEntity<String>("User delete Failed!!", HttpStatus.CONFLICT);
		}else {
			return new ResponseEntity<String>("User deleted Successfully", HttpStatus.OK);
		}
	}
	
	@GetMapping("adminControl/showBillsGeneratedToday")
	public List<OrderDTO> showAllBillsGeneratedToday() {		
		
		return restaurantService.getAllBillsGeneratedToday();
		
	}
	
	@GetMapping("adminControl/showTotalSalesOfCurrentMonth")
	public String showTotalSalesOfCurrentMonth() {	
		
		double totalSalesOfCurrentMonth = restaurantService.getTotalSalesOfCurrentMonth();		
		
		return "Total Sales of "+LocalDate.now().getMonth().toString()+" is "+String.valueOf(totalSalesOfCurrentMonth);
		
	}

	@ExceptionHandler(value = UserException.class)
	public ResponseEntity<String> handleUserException(
			UserException userException) {
		return new ResponseEntity<String>(userException.getMessage(), HttpStatus.CONFLICT);
	}

}
