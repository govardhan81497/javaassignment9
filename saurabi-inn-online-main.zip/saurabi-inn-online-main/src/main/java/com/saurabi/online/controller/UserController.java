package com.saurabi.online.controller;

import java.util.Collections;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.saurabi.online.entity.User;
import com.saurabi.online.entity.UserRole;
import com.saurabi.online.exception.UserException;
import com.saurabi.online.model.dto.UserDTO;
import com.saurabi.online.model.dto.UserDetailsDTO;
import com.saurabi.online.utility.AppUtility;

@RestController
public class UserController {
	
	@Autowired
	com.saurabi.online.service.UserService UserService;
	
	public boolean checkIfUserExistsByEmail(String email) {
		return UserService.userExists(email);
	}

	@PostMapping("user/registerUser")
	public ResponseEntity<String> registerUser(@Valid @RequestBody UserDetailsDTO userDetails) {

		if (!checkIfUserExistsByEmail(userDetails.getEmail())) {
			
			UserDTO userDTO = AppUtility.getUserDTOFromUserDetailsDTO(userDetails);
			
			userDTO.setAuthorities(Collections.singleton("ROLE_".concat(UserRole.USER.name())));
			
			final User createdUser = UserService.createSingleUser(userDTO);
			if(createdUser != null) {
				return new ResponseEntity<String>("User registered successfully", HttpStatus.CREATED);
			}else {
				return new ResponseEntity<String>("User registration Failed!!", HttpStatus.CONFLICT);
			}
		} else {
			throw new UserException(
					userDetails.getEmail().concat(" already exists. Please try with a different user"));
		}
	}
	
	@ExceptionHandler(value = UserException.class)
	public ResponseEntity<String> handleUserException(
			UserException userException) {
		return new ResponseEntity<String>(userException.getMessage(), HttpStatus.CONFLICT);
	}

}
