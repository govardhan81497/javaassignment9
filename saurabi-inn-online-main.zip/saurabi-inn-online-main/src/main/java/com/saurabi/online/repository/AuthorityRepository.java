package com.saurabi.online.repository;

import org.springframework.data.repository.CrudRepository;

import com.saurabi.online.entity.Authority;


public interface AuthorityRepository extends CrudRepository<Authority, Long>{

}
