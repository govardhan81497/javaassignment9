package com.saurabi.online;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaurabiInnOnlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
