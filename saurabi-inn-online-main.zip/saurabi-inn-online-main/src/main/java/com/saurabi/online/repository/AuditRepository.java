package com.saurabi.online.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saurabi.online.entity.AuditLog;

public interface AuditRepository extends JpaRepository<AuditLog, Long> {

}
