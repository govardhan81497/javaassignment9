package com.saurabi.online.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.saurabi.online.entity.Order;
import com.saurabi.online.model.dto.CreateOrderDTO;
import com.saurabi.online.model.dto.ItemDTO;
import com.saurabi.online.model.dto.OrderDTO;
import com.saurabi.online.service.RestaurantService;

@RestController
public class OnlineRestaurantController {
	
	@Autowired
	RestaurantService  restaurantService;
	
	@GetMapping("/")
	public String home() {
		return "<h1>Saurabhi Inn online</h1>";
		
	}
	
	@GetMapping("userControl/viewMenu")
	public List<ItemDTO> viewMenu() {
		return restaurantService.getAllItems();		 	
	}
	
	
	@PostMapping("userControl/placeOrder")
	public ResponseEntity<String> placeOrder(@Valid @RequestBody CreateOrderDTO orderDetails) {
		
		Order newOrder = restaurantService.createSingleOrder(orderDetails);
		if(newOrder != null) {
			return new ResponseEntity<String>("Order placed successfully", HttpStatus.CREATED);
		}else {
			return new ResponseEntity<String>("Order creation Failed!!", HttpStatus.CONFLICT);
		}		
	}
	
	@GetMapping("userControl/viewFinalBill")
	public OrderDTO viewFinalBill() {
		return restaurantService.getFinalBillOfUser();	 	
	}
	
}
