package com.saurabi.online.config;

import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.saurabi.online.entity.AuditLog;
import com.saurabi.online.entity.Order;
import com.saurabi.online.model.dto.CreateOrderDTO;
import com.saurabi.online.repository.AuditRepository;

@Aspect
@Configuration
public class AspectConfig {
	
	@Autowired
	AuditRepository auditRepository;
	
	@AfterReturning( pointcut="execution(public * com.saurabi.online.serviceImpl.RestaurantServiceImp.createSingleOrder(..) )" ,returning="newOrder")
	public void logForBillgeneration(JoinPoint joinPoint, Order newOrder) {
		
		AuditLog auditLog = AuditLog.builder().createdAt(new Date()).description("New Bill generated with Bill NO :"+newOrder.getId()+" with order details :: "+((CreateOrderDTO)joinPoint.getArgs()[0]).getOrderItemList()).build();
		auditRepository.saveAndFlush(auditLog);
		
	}
	

}
