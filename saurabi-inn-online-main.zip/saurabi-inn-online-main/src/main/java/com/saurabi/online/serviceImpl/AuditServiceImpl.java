package com.saurabi.online.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.saurabi.online.entity.AuditLog;
import com.saurabi.online.repository.AuditRepository;
import com.saurabi.online.service.AuditService;

@Service
public class AuditServiceImpl implements AuditService {
	
	@Autowired
	AuditRepository auditRepository;

	public List<AuditLog> getAllAuditLogs() {

		return auditRepository.findAll();
	}

}
