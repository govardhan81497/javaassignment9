package com.saurabi.online.utility;

import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import com.saurabi.online.entity.Item;
import com.saurabi.online.entity.Order;
import com.saurabi.online.entity.User;
import com.saurabi.online.model.dto.ItemDTO;
import com.saurabi.online.model.dto.OrderDTO;
import com.saurabi.online.model.dto.UserDTO;
import com.saurabi.online.model.dto.UserDetailsDTO;

public class AppUtility {

	public static UserDTO getUserDTOFromUserDetailsDTO(@Valid UserDetailsDTO userDetails) {

		if (userDetails != null) {
			UserDTO userDTO = new UserDTO();
			userDTO.setFirstname(userDetails.getFirstname());
			userDTO.setLastname(userDetails.getLastname());
			userDTO.setPassword(userDetails.getPassword());
			userDTO.setEmail(userDetails.getEmail());

			return userDTO;
		}
		return null;
	}

	public static UserDTO getUserDTOFromUser(User user) {
		if (user != null) {
			UserDTO userDTO = new UserDTO();
			userDTO.setFirstname(user.getFirstname());
			userDTO.setLastname(user.getLastname());
			userDTO.setPassword(user.getPassword());
			userDTO.setEmail(user.getEmail());
			userDTO.setAuthorities(user.getAuthorities().stream().map(e -> e.getAuthority().replace("ROLE_", ""))
					.collect(Collectors.toSet()));
			return userDTO;
		}
		return null;
	}
	
	public static ItemDTO getItemDTOFromItem(Item item) {
		
		if (item != null) {
			ItemDTO itemDTO = new ItemDTO();
			itemDTO.setItemId(item.getId());
			itemDTO.setName(item.getName());
			itemDTO.setPrice(item.getPrice());
			return itemDTO;
		}
		
		return null;
		
	}

	public static String getLoggedInUserName() {
		
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username ="";

		if (principal instanceof UserDetails) {
			username = ((UserDetails)principal).getUsername();
		} else {
			username = principal.toString();
		}
		
		return username;
	}

	public static OrderDTO getOrderDTOFromOrder(Order order) {
		if (order != null) {
			
			OrderDTO orderDTO = new OrderDTO();
			orderDTO.setCreatedAt(order.getCreatedAt());
			orderDTO.setGrandTotal(order.getGrandTotal());
			orderDTO.setBillNo(order.getId());
			orderDTO.setUser_id(order.getUserDetails().getUser_id());
			orderDTO.setEmail(order.getUserDetails().getEmail());
			return orderDTO;
		}
		return null;
	}

}
