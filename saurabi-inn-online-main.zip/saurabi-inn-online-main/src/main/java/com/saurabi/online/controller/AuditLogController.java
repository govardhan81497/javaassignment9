package com.saurabi.online.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.saurabi.online.entity.AuditLog;
import com.saurabi.online.serviceImpl.AuditServiceImpl;

@RestController
@RequestMapping("/adminControl")
public class AuditLogController {
	
	@Autowired
	AuditServiceImpl auditService;
	
	@GetMapping("/showAuditLogs")
	public List<AuditLog> showAuditLogs() {
		return auditService.getAllAuditLogs();
		
	}

}
